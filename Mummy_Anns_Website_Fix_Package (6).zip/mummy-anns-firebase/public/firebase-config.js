// Firebase web app configuration for MUMMY ANN'S FOOD AND CATERING PLACE.
// Firebase web config is intended to be included in public web apps.
export const firebaseConfig = {
  apiKey: 'AIzaSyDcnguiQmn8oy-XtDr27NG8KEPrvte1rOQ',
  authDomain: 'mummy-ann-s-food-and-catering.firebaseapp.com',
  projectId: 'mummy-ann-s-food-and-catering',
  storageBucket: 'mummy-ann-s-food-and-catering.firebasestorage.app',
  messagingSenderId: '224213688232',
  appId: '1:224213688232:web:affcc696a645550b33079d',
  measurementId: 'G-3062MB9TW5'
};
