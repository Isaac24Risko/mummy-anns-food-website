# MUMMY ANN'S FOOD AND CATERING PLACE — Firebase website

This starter includes a customer ordering page, an admin dashboard for three equal admins, Firestore rules, and Firebase Hosting configuration. It is not live until you create/configure your own Firebase project and deploy it.

## Included menu and prices
- Special moi moi ₦1,500; Jollof rice ₦1,500; White rice & sauce ₦1,500; Ewa aganyin ₦1,500; Bread ₦500
- Chicken ₦2,000; Egg ₦400; Beef ₦500; Fried fish ₦1,000; Ponmo (2 pieces) ₦500
- Coke ₦500; Fanta ₦500; Malt ₦800; Bottled water ₦300

## Setup (computer is easiest)
1. Go to https://console.firebase.google.com/ and sign in with the Google account that should own the business project. Create a project, e.g. `mummy-anns-food` (Firebase may require a unique project ID).
2. In Project Overview, choose **Add app** → Web (`</>`). Register the app. Copy the Firebase config object shown.
3. Edit `public/firebase-config.js`. Replace every placeholder with the exact values from your Firebase web app config. Keep the property names as shown. Do not paste service-account private keys here; this app does not need one.
4. In Firebase Console → **Build → Authentication → Get started → Sign-in method**, enable **Email/Password**.
5. In **Build → Firestore Database**, create a database. Choose a region near your customers, then create it. Do not leave it in test mode after setup.
6. From Firestore **Rules**, publish the contents of `firestore.rules` (or deploy with Firebase CLI as below). These rules let the public submit new pending orders but only approved admin UIDs read/update orders.
7. Create a **private** Supabase Storage bucket named `payment-receipts`. Configure the Netlify environment variables described below; do not make the bucket public. Receipts are limited to JPG/PNG/PDF under 3.5 MB. Admin receipt links are temporary and require a Firebase admin account.
8. Create three admin users under Authentication → Users → **Add user**. Use separate emails and strong unique passwords; share each password securely with its intended admin.
9. For each of the three users, copy the user's **UID** from Authentication → Users. In Firestore, create a collection named `admins` if needed. Add one document per admin whose **document ID is exactly that user's UID**. Add a field `role` of type string with value `admin`. Repeat for all three users. Do not use email as the document ID. The `admins/{UID}` document is the allow-list that grants order access.
10. Test locally using a web server (not by opening the HTML file directly). See CLI steps below. Test one customer order, then sign into `admin.html` with each of the three accounts and verify the same order appears on all three devices.

## Deploy with Firebase Hosting (computer required)
Install Node.js LTS from https://nodejs.org/ then open Terminal/Command Prompt in this project folder.

```bash
npm install -g firebase-tools
firebase login
firebase use --add
```
Choose the Firebase project you created and use the alias `default`. Then deploy:

```bash
firebase deploy --only firestore:rules,storage,hosting
```

Firebase will print a Hosting URL such as `https://YOUR_PROJECT_ID.web.app`. The customer order page is at that URL; the admin page is at `https://YOUR_PROJECT_ID.web.app/admin.html`. Share the customer URL publicly, but share the admin URL only with your three admins. Never share admin passwords publicly.

If `firebase use --add` asks for a project, select the same project whose config is in `public/firebase-config.js`. The generated `.firebaserc` should point to that project. Do not upload `.firebaserc.example` unchanged.

## Important security and operations notes
- Firebase web config is not a secret; the security boundary is Authentication + Firestore Rules. Never place service-account keys or admin private credentials in public files.
- Customers can submit orders without signing in. They cannot list/read other customers' orders or edit/cancel them from the website.
- Admin access is granted only when the signed-in UID has an `admins/{UID}` document. Create those documents manually in the console.
- All three admins have equal permissions by design. Status changes and payment verification are shared live through Firestore.
- Customers see the Moniepoint account details, upload a receipt, and orders remain Unverified until an admin reviews them. Storage rules protect receipt reads; customer uploads are limited by file type and size.
- The customer page currently uses the displayed menu prices as the total. Verify the prices before publishing. Delivery fees are not included.
- A customer can submit an order from a browser; this starter does not yet include online payments, delivery-zone fees, SMS/email alerts, or spam protection. Consider Firebase App Check and rate limiting before a high-traffic launch.
- Test Firestore rules in the Firebase Rules Playground or Emulator before relying on this for real orders.
