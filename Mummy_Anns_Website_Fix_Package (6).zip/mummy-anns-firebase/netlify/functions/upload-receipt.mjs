const headers = { "content-type": "application/json; charset=utf-8" };
const reply = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });
export const handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "Method not allowed" });
  try {
    const { orderId, fileName, contentType, data } = JSON.parse(event.body || "{}");
    if (!/^[A-Za-z0-9_-]{10,100}$/.test(orderId || "")) return reply(400, { error: "Invalid order reference" });
    if (!["image/jpeg", "image/png", "application/pdf"].includes(contentType)) return reply(400, { error: "Only JPG, PNG, or PDF receipts are allowed" });
    if (typeof data !== "string" || data.length < 1 || data.length > 4_900_000) return reply(413, { error: "Receipt is too large. Please use a file under 3.5 MB." });
    const bytes = Buffer.from(data, "base64");
    if (bytes.length > 3.5 * 1024 * 1024) return reply(413, { error: "Receipt must be under 3.5 MB." });
    const url = process.env.SUPABASE_URL;
    const key = process.env.SUPABASE_SECRET_KEY;
    if (!url || !key) return reply(500, { error: "Receipt service is not configured." });
    const path = `receipts/${orderId}/receipt`;
    const response = await fetch(`${url}/storage/v1/object/payment-receipts/${path}`, {
      method: "POST",
      headers: { apikey: key, authorization: `Bearer ${key}`, "content-type": contentType, "x-upsert": "false" },
      body: bytes
    });
    if (!response.ok) {
      const detail = await response.text();
      console.error("Supabase upload failed", response.status, detail);
      return reply(502, { error: "Receipt upload failed. Please try again." });
    }
    return reply(200, { path });
  } catch (e) {
    console.error(e);
    return reply(400, { error: "Invalid receipt request." });
  }
};
