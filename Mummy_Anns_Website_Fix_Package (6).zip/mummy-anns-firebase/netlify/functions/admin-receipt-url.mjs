const headers = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" };
const reply = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });
export const handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "Method not allowed" });
  try {
    const token = (event.headers?.authorization || event.headers?.Authorization || "").replace(/^Bearer\s+/i, "");
    if (!token) return reply(401, { error: "Please sign in as an admin." });
    const { receiptPath } = JSON.parse(event.body || "{}");
    if (typeof receiptPath !== "string" || !/^receipts\/[A-Za-z0-9_-]{10,100}\/receipt$/.test(receiptPath)) return reply(400, { error: "Invalid receipt reference." });
    const apiKey = process.env.FIREBASE_API_KEY;
    const projectId = process.env.FIREBASE_PROJECT_ID;
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_SECRET_KEY;
    if (!apiKey || !projectId || !supabaseUrl || !supabaseKey) return reply(500, { error: "Receipt service is not fully configured." });
    // Ask Firebase Authentication to validate the ID token and return its UID.
    const authRes = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(apiKey)}`, {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ idToken: token })
    });
    if (!authRes.ok) return reply(401, { error: "Your sign-in has expired. Please sign in again." });
    const authData = await authRes.json();
    const uid = authData.users?.[0]?.localId;
    if (!uid) return reply(401, { error: "Could not verify your admin account." });
    // Firestore rules allow a signed-in user to read only their own admins/{UID} record.
    const adminRes = await fetch(`https://firestore.googleapis.com/v1/projects/${encodeURIComponent(projectId)}/databases/(default)/documents/admins/${encodeURIComponent(uid)}`, {
      headers: { authorization: `Bearer ${token}` }
    });
    if (!adminRes.ok) return reply(403, { error: "This account is not authorized to view receipts." });
    const signedRes = await fetch(`${supabaseUrl}/storage/v1/object/sign/payment-receipts/${receiptPath}`, {
      method: "POST", headers: { apikey: supabaseKey, authorization: `Bearer ${supabaseKey}`, "content-type": "application/json" },
      body: JSON.stringify({ expiresIn: 120 })
    });
    const signed = await signedRes.json().catch(() => ({}));
    if (!signedRes.ok || !signed.signedURL) {
      console.error("Supabase signed URL failed", signedRes.status, signed);
      return reply(404, { error: "Receipt not found or unavailable." });
    }
    const signedURL = signed.signedURL.startsWith("http") ? signed.signedURL : `${supabaseUrl}/storage/v1${signed.signedURL}`;
    return reply(200, { url: signedURL });
  } catch (e) {
    console.error(e);
    return reply(500, { error: "Could not retrieve receipt." });
  }
};
