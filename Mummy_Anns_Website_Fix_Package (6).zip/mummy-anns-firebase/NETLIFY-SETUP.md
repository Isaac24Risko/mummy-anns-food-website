# Publish MUMMY ANN'S FOOD AND CATERING PLACE with Netlify + Firebase

## Before publishing
1. Create a Firebase project at https://console.firebase.google.com/.
2. Add a Web app and copy its config into `public/firebase-config.js`, replacing all placeholder values.
3. In Firebase Authentication, enable Email/Password.
4. Create Cloud Firestore.
5. Open Firestore > Rules and publish the contents of `firestore.rules`.
6. Open Firebase Console > **Storage** and set up the default Storage bucket. If Google asks you to upgrade to the Blaze billing plan to create/use Storage, website receipt uploads require that upgrade; review Google's current pricing and billing settings before proceeding.
7. Keep the Supabase `payment-receipts` bucket private. Do not add public read policies.
8. Create three admin users under Authentication > Users. For each user, copy the UID and create a Firestore document in the `admins` collection with the document ID exactly equal to that UID and a string field `role` = `admin`.

## Deploy on Netlify

### Easiest on a computer
1. Extract this ZIP to a folder.
2. Confirm `public/index.html`, `public/admin.html`, and `public/firebase-config.js` are present and the Firebase config is filled in.
3. Sign in at https://app.netlify.com/.
4. Open https://app.netlify.com/drop and upload/drag the **public** folder (not the parent project folder). If using Netlify's manual deploy area, choose the `public` folder as the publish output.
5. Netlify creates a site with a URL ending in `.netlify.app`. In Site configuration / Domain management, customize the site name if the name you want is available.
6. Customer page is the base URL; the admin page is the same URL followed by `/admin.html`.

### If using a phone
The Netlify drag-and-drop workflow is much easier on a computer. On Android, extract the ZIP with a file manager first; then use Netlify's site deployment UI if it lets you select the extracted `public` folder. If the browser only lets you choose files and not a folder, use a computer or deploy from a Git repository instead.

## Test before sharing
- Submit a small test order on the customer page.
- Sign in at `/admin.html` with each of the three admin accounts.
- Confirm all three accounts see the same order and can update its status.
- Submit a test order with a receipt, then verify an admin can open the receipt and set payment verification to Verified or Rejected.
- Delete test orders if desired before opening to customers.

## Important
- This project is not live until you complete Firebase setup and Netlify deployment.
- The Firebase web config is intended to be public; never put service-account private keys in these files.
- Never use open/test-mode Firestore or Storage rules for a public website.
- Receipt images/PDFs are stored in Firebase Storage. The admin dashboard retrieves a receipt only after an admin signs in; never share receipt download links publicly.
- Admin page URL is not secret by itself; security comes from Firebase Authentication and Firestore rules.
- A Netlify URL alone does not configure Firebase or create admin accounts.


## Supabase receipt storage environment variables
In Netlify → Site configuration → Environment variables, add these variables. Mark `SUPABASE_SECRET_KEY` as secret:
- `SUPABASE_URL` = your Supabase project URL (without `/rest/v1/`)
- `SUPABASE_SECRET_KEY` = Supabase secret key (keep secret; never add to public files)
- `FIREBASE_API_KEY` = the `apiKey` value from `public/firebase-config.js`
- `FIREBASE_PROJECT_ID` = `mummy-ann-s-food-and-catering`
After changing environment variables, trigger a new deploy. The project uses Netlify Functions under `netlify/functions/`; deploy the **project root** (not only the `public` folder) so those functions are included.
